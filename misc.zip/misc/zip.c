#include <arpa/inet.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <pty.h>

char token[1024], buf[1024];

void load() {
    FILE *f = fopen("token.txt", "r");
    fgets(token, sizeof(token), f);
    token[64] = 0; // maybe 64 bytes is enough
    fclose(f);
}

int cmpstr(char const *a, char const *b) {
    return memcmp(a, b, strlen(a));
}

void zip(char *password) {
    int master, pid;
    pid = forkpty(&master, NULL, NULL, NULL);

    if (pid == 0) {
        char* argv[] = { "7z", "a", "flag.zip", "tmp/flag.txt", "-mem=AES256", "-p", NULL };
        execve("/usr/bin/7z", argv, NULL);
    } else {
        char buffer[4097];
        while (true) {
            ssize_t n = read(master, buffer, 4096);
            if (n < 0) break;
            fflush(stdout);
            write(1, buffer, n);

            buffer[n] = 0;
            if (strstr(buffer, "password")) {
                usleep(10000);
                write(master, password, strlen(password));
                write(master, "\n", 1);
            }
        }
        wait(NULL);
    }
    close(master);
}

void unzip(char *password) {
    int master, pid;
    pid = forkpty(&master, NULL, NULL, NULL);

    if (pid == 0) {
        char* argv[] = { "7z", "e", "flag.zip", NULL };
        execve("/usr/bin/7z", argv, NULL);
    } else {
        char buffer[4097];
        while (true) {
            ssize_t n = read(master, buffer, 4096);
            if (n < 0) break;
            fflush(stdout);
            write(1, buffer, n);

            buffer[n] = 0;
            if (strstr(buffer, "rename all")) {
                usleep(10000);
                write(master, "u\n", 2);
            }

            if (strstr(buffer, "Enter password")) {
                usleep(10000);
                write(master, password, strlen(password));
                write(master, "\n", 1);
            }
        }
        wait(NULL);
    }
    close(master);
}

int main(int argc, char *argv[]) {
    load();
    system("7z");

    puts("your token:");
    fflush(stdout);
    fgets(buf, sizeof(buf), stdin);
    if (cmpstr(token, buf)) {
        puts("wrong token!");
        return 1;
    }

    zip(buf);

    puts("your flag:");
    fflush(stdout);

    fgets(buf, sizeof(buf), stdin);
    if (cmpstr("flag{", buf)) {
        puts("wrong flag!");
        return 1;
    }

    unzip(buf);

    FILE *f = fopen("flag.txt", "r");
    if (!f) {
        puts("flag.txt not found");
        return 1;
    }
    fgets(buf, sizeof(buf), f);
    fclose(f);

    printf("flag: %s\n", buf);

    return 0;
}
